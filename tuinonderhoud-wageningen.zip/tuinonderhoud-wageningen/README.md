# Tuinonderhoud Wageningen – website

Website van Robin en Stian. De site bestaat alleen uit losse bestanden (HTML, CSS en JavaScript) en werkt daardoor gratis op **GitHub Pages**. Er is geen server nodig.

## Mappen

```
index.html            de pagina zelf
css/style.css         alle opmaak
js/main.js            menu, voor/na-schuifbalk, prijs-zoekbalk, rekenmachine
js/tuinscanner.js     "Wat kost jouw tuin?" (adres → kadastrale kaart → m² tuin → prijs)
img/                  foto's
vendor/leaflet/       kaartbibliotheek Leaflet 1.9.4 (BSD-licentie)
```

## Online zetten met GitHub Pages

1. Maak op github.com een nieuwe repository, bijvoorbeeld `tuinonderhoud-wageningen`.
2. Klik op **Add file → Upload files** en sleep de *inhoud* van deze map erin (dus `index.html` moet bovenaan staan, niet in een submap). Klik op **Commit changes**.
3. Ga naar **Settings → Pages**. Kies bij *Source* "Deploy from a branch", branch `main`, map `/ (root)`, en klik op **Save**.
4. Na een minuutje staat de site op `https://<jouw-gebruikersnaam>.github.io/tuinonderhoud-wageningen/`.

Een eigen domeinnaam kan later via **Settings → Pages → Custom domain**.

## Prijzen aanpassen

- **Tuinscanner:** bovenaan `js/tuinscanner.js` staat het blok `PRIJZEN` (klein = 50 m², middel = 150 m², groot = 250 m²; daartussen rekent hij het naar verhouding uit).
- **Zoekbalk en rekenmachine:** in `js/main.js` staan de lijsten `TASKS` en `SIZE_PRICES`.
- **Teksten:** in `index.html`.

## Waar komen de kaartgegevens vandaan?

Alles is gratis open data van het Kadaster via PDOK. Je hebt er geen account of sleutel voor nodig:

- Adressen zoeken: PDOK Locatieserver (`api.pdok.nl/bzk/locatieserver/search/v3_1`)
- Kadastrale percelen: Kadastrale Kaart OGC API (`api.pdok.nl/kadaster/brk-kadastrale-kaart/ogc/v1`)
- Gebouwen: BAG OGC API (`api.pdok.nl/kadaster/bag/ogc/v2`)
- Luchtfoto: PDOK luchtfoto WMTS (`service.pdok.nl/hwh/luchtfotorgb`)
- Gewone kaart: BRT Achtergrondkaart WMTS (`service.pdok.nl/brt/achtergrondkaart`)
- Kadastrale grenzen op de kaart: Kadastrale Kaart WMS (`service.pdok.nl/kadaster/kadastralekaart/wms/v5_0`)

De kadastrale kaart is een indicatie en geen exacte meting. Daarom kan de klant de m² altijd zelf aanpassen. Lukt het ophalen een keer niet, dan kan de klant de m² gewoon zelf invullen.

## Lokaal bekijken

Open `index.html` in je browser. Voor de kaart is internet nodig.
