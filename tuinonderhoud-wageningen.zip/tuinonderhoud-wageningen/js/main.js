  // Before/after compare slider
  (function(){
    document.querySelectorAll('.compare').forEach((compare) => {
      const afterWrap = compare.querySelector('.after-wrap');
      const handle = compare.querySelector('.handle');
      const range = compare.querySelector('input[type="range"]');
      function update(val){
        afterWrap.style.clipPath = `inset(0 0 0 ${val}%)`;
        handle.style.left = val + '%';
      }
      range.addEventListener('input', (e) => update(e.target.value));
      update(50);
    });
  })();

  // Voor & na: wissel met de bolletjes
  (function(){
    const dots=[...document.querySelectorAll('.vn-dot')];
    const slides=[...document.querySelectorAll('.vn-slide')];
    dots.forEach((d,i)=>d.addEventListener('click',()=>{
      dots.forEach((x,j)=>{ x.classList.toggle('is-active',i===j); x.setAttribute('aria-selected',i===j); });
      slides.forEach((x,j)=>x.classList.toggle('is-active',i===j));
    }));
  })();

  // Prijs-zoekbalk met suggesties
  (function(){
    const input = document.getElementById('priceSearch');
    if(!input) return;
    const list = document.getElementById('psList');
    const box = document.getElementById('psearch');
    const res = document.getElementById('psResult');
    const MIN = 25, WA = 'https://wa.me/31643444758';
    const SIZES = [
      { key:'klein',  name:'kleine tuin',  range:'tot 50 m²',   max:50 },
      { key:'middel', name:'middelgrote tuin', range:'50–150 m²', max:150 },
      { key:'groot',  name:'grote tuin',   range:'150 m²+',     max:Infinity },
    ];
    const eur = n => '€' + n.toLocaleString('nl-NL', { minimumFractionDigits: n % 1 ? 2 : 0, maximumFractionDigits: 2 });
    const withMin = n => Math.max(MIN, n);
    const sizeFor = m2 => SIZES.find(s => m2 <= s.max);
    // g: true = er komt groenafval bij kijken (afvoeren met de afvalpas van de klant)
    const TASKS = [
      { label:'Blad ruimen', words:['blad','bladeren','blaadjes','herfst','harken','bladruimen'], prices:{klein:30, middel:55, groot:95}, g:true },
      { label:'Gras maaien + randen', words:['gras','maaien','gazon','grasmaaien','randen'], prices:{klein:20, middel:30, groot:50}, g:true },
      { label:'Onkruid wieden (borders)', words:['onkruid','wieden','border','borders','perken'], prices:{klein:30, middel:55, groot:95}, g:true },
      { label:'Terras / tegels: onkruid uit de voegen', words:['tegels','terras','voegen','voeg','oprit','pad','paden','bestrating'], perM2:1.5, unitM2:'m² bestrating', g:true },
      { label:'Heg snoeien', words:['heg','haag','heggen','snoeien','coniferen','conifeer'], perMeter:3, g:true },
      { label:'Struiken snoeien', words:['struik','struiken','snoeien','rozen','bosjes'], perPiece:7, unit:'struik', units:'struiken', g:true },
      { label:'Kleine boom snoeien (tot ± 4 m)', words:['boom','bomen','fruitboom','snoeien','takken'], perPiece:30, unit:'boom', units:'bomen', g:true },
      { label:'Tuin opruimen', words:['opruimen','opruim','rommel','troep','schoonmaken','tuin'], prices:{klein:30, middel:55, groot:95}, g:true },
      { label:'Tuin winterklaar maken', words:['winter','winterklaar','najaar','herfst','najaarsbeurt'], prices:{klein:50, middel:90, groot:145}, g:true },
      { label:'Voorjaarsbeurt', words:['voorjaar','lente','voorjaarsbeurt','voorjaarssnoei'], prices:{klein:50, middel:90, groot:145}, g:true },
      { label:'Complete onderhoudsbeurt', words:['compleet','complete','onderhoud','onderhoudsbeurt','alles','beurt'], prices:{klein:60, middel:100, groot:160}, g:true },
      { label:'Tuin klaarmaken voor verkoop/verhuur', words:['verkoop','verhuur','verhuizen','verhuizing','makelaar','huurder'], prices:{klein:60, middel:100, groot:160}, g:true },
      { label:'Dakgoot leeghalen', words:['dakgoot','goot','dakgoten','regenpijp'], fixed:35, unit:'per huis', g:true },
      { label:'Planten of bloembollen poten', words:['planten','plant','bollen','bloembollen','poten','bloemen'], from:25 },
      { label:'Kleine reparatie bestrating', words:['bestrating','tegel','tegels','stoep','herstellen','reparatie','losse'], from:30 },
      { label:'Klein tuinmuurtje herstellen', words:['muur','muurtje','tuinmuur','herstellen'], from:30 },
      { label:'Groenafval wegbrengen (met jouw afvalpas)', words:['afvoeren','afvoer','rit','ritten','wegbrengen','stort','milieustraat','afvalbrengstation','groenafval','tuinafval','afval','container'], perPiece:10, unit:'rit', units:'ritten', noMin:true, note:'Komt bovenop je klus. We brengen het naar het afvalbrengstation aan de Nude met jouw afvalpas.' },
    ];
    const STOP = ['m','m2','meter','vierkante','bij','van','de','het','een','mijn','met','en','voor','laten','graag','wil','ik','stuks','stuk','x'];

    function parse(q){
      q = q.toLowerCase().replace(',', '.');
      const num = q.match(/(\d+(?:\.\d+)?)\s*(m²|m2|vierkante|vk|meter|m\b|stuks|stuk|x)?/);
      let n = null, unit = '';
      if(num){ n = parseFloat(num[1]); unit = num[2] || ''; }
      const words = q.replace(/[\d.,²]+/g,' ').split(/\s+/).filter(w => w.length > 1 && !STOP.includes(w));
      const score = t => words.filter(w => t.words.some(k => k.startsWith(w) || (w.length > 3 && w.startsWith(k)))).length;
      let tasks = words.length
        ? TASKS.map(t => [t, score(t)]).filter(x => x[1] > 0).sort((a, b) => b[1] - a[1]).map(x => x[0])
        : TASKS.filter(t => ['Blad ruimen','Gras maaien + randen','Heg snoeien','Tuin winterklaar maken','Complete onderhoudsbeurt','Dakgoot leeghalen'].includes(t.label));
      return { tasks, n, unit, hasWords: words.length > 0 };
    }

    function suggestions(q){
      const { tasks, n, unit, hasWords } = parse(q);
      const isArea = /m²|m2|vierkante|vk/.test(unit) || (n && !unit);
      const isLen = /meter|m/.test(unit) || (n && !unit);
      const many = hasWords && tasks.length <= 2;
      const out = [];
      tasks.forEach(t => {
        if(t.prices){
          if(n && isArea){
            const s = sizeFor(n);
            out.push({ task:t, label:t.label, sub: Math.round(n) + ' m² · ' + s.name, price: withMin(t.prices[s.key]), from: s.key === 'groot',
              note: n > 300 ? 'Voor zo\'n grote tuin maken we na een kijkje een prijs op maat.' : '' });
          } else (many ? SIZES : [SIZES[1]]).forEach(s => out.push({ task:t, label:t.label, sub: s.name + ', ' + s.range, price: withMin(t.prices[s.key]), from: s.key === 'groot' }));
        } else if(t.perMeter){
          (n && isLen ? [Math.round(n)] : many ? [5, 10, 20] : [10]).forEach(m =>
            out.push({ task:t, label:t.label, sub: m + ' meter · ' + eur(t.perMeter) + ' per meter', price: withMin(m * t.perMeter) }));
        } else if(t.perM2){
          (n && isArea ? [Math.round(n)] : many ? [10, 25, 50] : [25]).forEach(m =>
            out.push({ task:t, label:t.label, sub: m + ' ' + t.unitM2 + ' · ' + eur(t.perM2) + ' per m²', price: withMin(m * t.perM2) }));
        } else if(t.perPiece){
          (n && !/m²|m2|vierkante|vk|meter|^m$/.test(unit) ? [Math.round(n)] : many ? [1, 3, 5] : [1]).forEach(k =>
            out.push({ task:t, label:t.label, sub: k + ' ' + (k === 1 ? t.unit : t.units) + ' · ' + eur(t.perPiece) + ' per ' + t.unit, price: t.noMin ? k * t.perPiece : withMin(k * t.perPiece), note: t.note || '' }));
        } else if(t.fixed){
          out.push({ task:t, label:t.label, sub: t.unit, price: withMin(t.fixed) });
        } else if(t.from){
          out.push({ task:t, label:t.label, sub: 'prijs na een kijkje', price: t.from, from: true });
        }
      });
      return out.slice(0, 10);
    }

    let items = [], active = -1;
    function render(){
      items = suggestions(input.value.trim());
      list.innerHTML = '';
      if(!items.length){
        const li = document.createElement('li');
        li.className = 'ps-empty';
        li.innerHTML = 'Staat je klus er niet bij? <a href="' + WA + '" target="_blank" rel="noopener">Vraag het ons via WhatsApp</a>';
        list.append(li);
      }
      items.forEach((it, i) => {
        const li = document.createElement('li');
        li.setAttribute('role','option'); li.id = 'ps-opt-' + i;
        const left = document.createElement('div');
        left.textContent = it.label;
        const sm = document.createElement('small'); sm.textContent = it.sub; left.append(sm);
        const right = document.createElement('span'); right.className = 'pp';
        right.textContent = (it.from ? 'vanaf ' : '') + eur(it.price);
        li.append(left, right);
        li.addEventListener('mousedown', e => { e.preventDefault(); choose(i); });
        list.append(li);
      });
      active = -1; open(true);
    }
    function open(v){ list.hidden = !v; input.setAttribute('aria-expanded', v); }
    function highlight(i){
      [...list.children].forEach((li, j) => li.classList.toggle('is-active', j === i));
      active = i;
      if(i >= 0){ input.setAttribute('aria-activedescendant', 'ps-opt-' + i); list.children[i].scrollIntoView({ block:'nearest' }); }
    }
    function choose(i){
      const it = items[i]; if(!it) return;
      document.getElementById('psrLabel').textContent = it.label + ' · ' + it.sub;
      document.getElementById('psrPrice').innerHTML = (it.from ? '<small>vanaf</small>' : '') + eur(it.price);
      let note = 'Dit is een inschatting. We komen gratis kijken en daarna is alles in overleg.';
      if(it.price === MIN) note = 'Minimumprijs per bezoek is ' + eur(MIN) + '. ' + note;
      if(it.note) note = it.note + ' ' + note;
      if(it.task.g) note += ' Groenafval gaat in je groene container, of we brengen het weg met jouw afvalpas.';
      document.getElementById('psrNote').textContent = note;
      const msg = 'Hoi Robin en Stian! Ik wil graag: ' + it.label + ', ' + it.sub + ', inschatting ' + (it.from ? 'vanaf ' : '') + eur(it.price) + '. Wanneer kunnen jullie komen kijken?';
      document.getElementById('psrBtn').href = WA + '?text=' + encodeURIComponent(msg);
      res.hidden = false;
      open(false);
    }
    input.addEventListener('input', render);
    input.addEventListener('focus', render);
    input.addEventListener('blur', () => setTimeout(() => open(false), 120));
    input.addEventListener('keydown', e => {
      if(list.hidden && (e.key === 'ArrowDown')){ render(); return; }
      if(e.key === 'ArrowDown'){ e.preventDefault(); highlight(Math.min(items.length - 1, active + 1)); }
      else if(e.key === 'ArrowUp'){ e.preventDefault(); highlight(Math.max(0, active - 1)); }
      else if(e.key === 'Enter'){ e.preventDefault(); choose(active >= 0 ? active : 0); }
      else if(e.key === 'Escape'){ open(false); }
    });
    document.querySelectorAll('.psearch-chips button').forEach(b => b.addEventListener('click', () => {
      input.value = b.dataset.q; input.focus(); render();
    }));
  })();

  // Price calculator — vaste prijzen per klus
  (function(){
    const MIN_PRICE = 25;      // minimum per bezoek
    const HEG_PER_M = 3;       // heg snoeien, per meter
    const DAKGOOT = 35;        // dakgoot leeghalen, per huis
    const SIZE_PRICES = {
      blad:    { label: 'Blad ruimen', klein: 30, middel: 55, groot: 95 },
      maaien:  { label: 'Gras maaien + randen',   klein: 20, middel: 30, groot: 50 },
      onkruid: { label: 'Onkruid wieden',         klein: 30, middel: 55, groot: 95 },
    };
    const SIZE_LABELS = { klein: 'klein (tot 50 m²)', middel: 'middel (50–150 m²)', groot: 'groot (150 m²+)' };

    const serviceBoxes = Array.from(document.querySelectorAll('#calcServices input[type="checkbox"]'));
    const sizeRadios = Array.from(document.querySelectorAll('#calcSizeGroup input[type="radio"]'));
    const hegGroup = document.getElementById('calcHegGroup');
    const hegInput = document.getElementById('calcHeg');
    const linesEl = document.getElementById('calcLines');
    const priceEl = document.getElementById('calcPrice');
    const noteEl = document.getElementById('calcNote');
    if(!serviceBoxes.length) return;

    const money = (n) => '€' + n.toLocaleString('nl-NL', { minimumFractionDigits: n % 1 ? 2 : 0, maximumFractionDigits: 2 });

    function syncCheckedStyles(){
      serviceBoxes.forEach(b => b.closest('.calc-check').classList.toggle('is-checked', b.checked));
      sizeRadios.forEach(r => r.closest('.calc-radio').classList.toggle('is-checked', r.checked));
    }

    function update(){
      const chosen = serviceBoxes.filter(b => b.checked).map(b => b.value);
      const size = (sizeRadios.find(r => r.checked) || sizeRadios[1]).value;
      hegGroup.hidden = !chosen.includes('heg');

      const lines = [];
      chosen.forEach(v => {
        if(SIZE_PRICES[v]) lines.push([SIZE_PRICES[v].label, SIZE_PRICES[v][size], size === 'groot']);
        if(v === 'heg'){
          const m = Math.max(1, Math.round(Number(hegInput.value) || 0));
          lines.push(['Heg snoeien · ' + m + ' m', m * HEG_PER_M, false]);
        }
        if(v === 'dakgoot') lines.push(['Dakgoot leeghalen', DAKGOOT, false]);
      });

      linesEl.innerHTML = '';
      lines.forEach(([label, amount, from]) => {
        const row = document.createElement('div');
        row.className = 'calc-row';
        const l = document.createElement('span'); l.textContent = label;
        const r = document.createElement('span'); r.className = 'mono'; r.textContent = (from ? 'vanaf ' : '') + money(amount);
        row.append(l, r); linesEl.append(row);
      });

      if(!lines.length){
        priceEl.textContent = '—';
        noteEl.textContent = chosen.includes('anders')
          ? 'Vertel ons gewoon wat je nodig hebt, dan maken we samen een prijs op maat.'
          : 'Kies hierboven wat er moet gebeuren.';
        return;
      }

      let total = lines.reduce((sum, l) => sum + l[1], 0);
      const raisedToMin = total < MIN_PRICE;
      if(raisedToMin) total = MIN_PRICE;
      const isFrom = lines.some(l => l[2]);
      priceEl.textContent = (isFrom ? 'vanaf ' : '') + money(total);

      let note = 'Tuin: ' + SIZE_LABELS[size] + '. We komen altijd eerst gratis kijken en bevestigen de vaste prijs vooraf.';
      if(raisedToMin) note = 'De minimumprijs per bezoek is ' + money(MIN_PRICE) + '. ' + note;
      if(chosen.includes('anders')) note += ' Iets anders erbij? Vertel het ons, dan rekenen we het mee.';
      noteEl.textContent = note;
    }

    serviceBoxes.forEach(b => b.addEventListener('change', () => { syncCheckedStyles(); update(); }));
    sizeRadios.forEach(r => r.addEventListener('change', () => { syncCheckedStyles(); update(); }));
    hegInput.addEventListener('input', update);
    syncCheckedStyles();
    update();
  })();

  // Scroll reveal
  (function(){
    const items = document.querySelectorAll('.reveal');
    if(!('IntersectionObserver' in window)){
      items.forEach(el => el.classList.add('show'));
      return;
    }
    const io = new IntersectionObserver((entries)=>{
      entries.forEach(entry=>{
        if(entry.isIntersecting){
          entry.target.classList.add('show');
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12 });
    items.forEach(el => io.observe(el));
  })();
