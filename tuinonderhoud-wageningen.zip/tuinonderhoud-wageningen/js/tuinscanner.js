/*
  Tuinscanner — Tuinonderhoud Wageningen
  ---------------------------------------
  1. Adres zoeken via de PDOK Locatieserver (suggest + lookup)
  2. Kadastraal perceel ophalen waar het adres op ligt (PDOK Kadastrale Kaart, OGC API)
  3. Gebouwen (BAG panden) op dat perceel ophalen en eraf halen
  4. Tuinoppervlak (m²) => inschatting per klus

  Alles draait in de browser, dus het werkt gewoon op GitHub Pages.
  Prijzen aanpassen? Zie het blok PRIJZEN hieronder.
*/
(function () {
  'use strict';

  // ------------------------------------------------------------------
  // PRIJZEN (in euro's). Klein = 50 m², middel = 150 m², groot = 250 m².
  // Daartussen rekent de scanner het naar verhouding uit.
  // ------------------------------------------------------------------
  const MIN_PRICE = 25;          // minimum per bezoek
  const UURTARIEF = 12.5;        // per persoon per uur
  const WA = 'https://wa.me/31643444758';

  const SIZE_TASKS = {
    blad:      { label: 'Blad ruimen',              klein: 30, middel: 55,  groot: 95 },
    maaien:    { label: 'Gras maaien + randen',     klein: 20, middel: 30,  groot: 50 },
    onkruid:   { label: 'Onkruid wieden (borders)', klein: 30, middel: 55,  groot: 95 },
    opruimen:  { label: 'Tuin opruimen',            klein: 30, middel: 55,  groot: 95 },
    winter:    { label: 'Tuin winterklaar maken',   klein: 50, middel: 90,  groot: 145 },
    compleet:  { label: 'Complete onderhoudsbeurt', klein: 60, middel: 100, groot: 160 },
  };
  const EXTRA_TASKS = {
    terras:  { label: 'Terras / voegen onkruidvrij', per: 1.5, unit: 'm²',     input: 'tsTerras' },
    heg:     { label: 'Heg snoeien',                 per: 3,   unit: 'meter',  input: 'tsHeg' },
    struik:  { label: 'Struiken snoeien',            per: 7,   unit: 'struik', units: 'struiken', input: 'tsStruik' },
    dakgoot: { label: 'Dakgoot leeghalen',           fixed: 35 },
    afvoer:  { label: 'Groenafval wegbrengen',       per: 10,  unit: 'rit', units: 'ritten', input: 'tsAfvoer', noMin: true },
  };

  // PDOK endpoints (gratis, open data, geen sleutel nodig)
  const LS  = 'https://api.pdok.nl/bzk/locatieserver/search/v3_1';
  const KK  = 'https://api.pdok.nl/kadaster/brk-kadastrale-kaart/ogc/v1/collections/perceel/items';
  const BAG = 'https://api.pdok.nl/kadaster/bag/ogc/v2/collections/pand/items';
  const LUCHTFOTO = 'https://service.pdok.nl/hwh/luchtfotorgb/wmts/v1_0/Actueel_orthoHR/EPSG:3857/{z}/{x}/{y}.jpeg';
  const BRT = 'https://service.pdok.nl/brt/achtergrondkaart/wmts/v2_0/standaard/EPSG:3857/{z}/{x}/{y}.png';
  const KADKAART_WMS = 'https://service.pdok.nl/kadaster/kadastralekaart/wms/v5_0';
  const WAGENINGEN = [51.9692, 5.6654];

  // ------------------------------------------------------------------
  const $ = (id) => document.getElementById(id);
  const root = $('tuinscanner');
  if (!root) return;

  const addr = $('tsAddr'), list = $('tsList'), status = $('tsStatus');
  const areaInput = $('tsArea');
  const state = { address: null, gemeente: null, parcelM2: null, buildingM2: null };

  const eur = (n) => '€' + n.toLocaleString('nl-NL', { minimumFractionDigits: n % 1 ? 2 : 0, maximumFractionDigits: 2 });
  const round5 = (n) => Math.round(n / 5) * 5;
  const m2 = (n) => Math.round(n).toLocaleString('nl-NL') + ' m²';

  function setStatus(msg, kind) {
    status.textContent = msg || '';
    status.className = 'ts-status' + (kind ? ' is-' + kind : '');
  }

  // Prijs voor een klus op basis van tuinoppervlak (vloeiend tussen klein/middel/groot)
  function sizePrice(t, a) {
    if (a <= 50) return Math.max(t.klein * Math.max(0.7, a / 50), 0);
    if (a <= 150) return t.klein + (t.middel - t.klein) * (a - 50) / 100;
    if (a <= 250) return t.middel + (t.groot - t.middel) * (a - 150) / 100;
    return t.groot + (t.groot - t.middel) * (a - 250) / 100;
  }

  // ------------------------------------------------------------------
  // Kaart
  // ------------------------------------------------------------------
  let map = null, layers = null;
  function initMap() {
    if (map || typeof L === 'undefined') return;
    map = L.map('tsMap', { scrollWheelZoom: false, zoomControl: true, attributionControl: true })
      .setView(WAGENINGEN, 14);
    map.attributionControl.setPrefix('<a href="https://leafletjs.com" target="_blank" rel="noopener">Leaflet</a>');
    const attr = 'Kaartdata: <a href="https://www.pdok.nl" target="_blank" rel="noopener">Kadaster / PDOK</a>';
    const luchtfoto = L.tileLayer(LUCHTFOTO, { maxZoom: 21, maxNativeZoom: 19, attribution: attr }).addTo(map);
    const kaart = L.tileLayer(BRT, { maxZoom: 21, maxNativeZoom: 19, attribution: attr });
    const kadaster = L.tileLayer.wms(KADKAART_WMS, {
      layers: 'Kadastralekaart', format: 'image/png', transparent: true, version: '1.3.0',
      maxZoom: 21, minZoom: 16, attribution: attr,
    }).addTo(map);
    L.control.layers({ 'Luchtfoto': luchtfoto, 'Kaart': kaart }, { 'Kadastrale grenzen': kadaster }, { collapsed: false, position: 'topright' }).addTo(map);
    layers = L.layerGroup().addTo(map);
    root.querySelector('.ts-map-empty')?.remove();
  }

  // ------------------------------------------------------------------
  // Geometrie-hulpjes (lokale projectie in meters is nauwkeurig genoeg voor één tuin)
  // ------------------------------------------------------------------
  function polysOf(geom) {
    if (!geom) return [];
    if (geom.type === 'Polygon') return [geom.coordinates];
    if (geom.type === 'MultiPolygon') return geom.coordinates;
    return [];
  }
  function inRing(x, y, ring) {
    let inside = false;
    for (let i = 0, j = ring.length - 1; i < ring.length; j = i++) {
      const xi = ring[i][0], yi = ring[i][1], xj = ring[j][0], yj = ring[j][1];
      if (((yi > y) !== (yj > y)) && (x < (xj - xi) * (y - yi) / (yj - yi) + xi)) inside = !inside;
    }
    return inside;
  }
  function inPolys(x, y, polys) {
    return polys.some((rings) => inRing(x, y, rings[0]) && !rings.slice(1).some((h) => inRing(x, y, h)));
  }
  function ringArea(r) {
    let s = 0;
    for (let i = 0, j = r.length - 1; i < r.length; j = i++) s += (r[j][0] + r[i][0]) * (r[j][1] - r[i][1]);
    return Math.abs(s / 2);
  }
  function project(polys, lat0, lon0) {
    const kx = 111320 * Math.cos(lat0 * Math.PI / 180), ky = 110574;
    return polys.map((rings) => rings.map((ring) => ring.map(([lon, lat]) => [(lon - lon0) * kx, (lat - lat0) * ky])));
  }
  function bboxOf(polys) {
    let a = [Infinity, Infinity, -Infinity, -Infinity];
    polys.forEach((r) => r[0].forEach(([x, y]) => { a = [Math.min(a[0], x), Math.min(a[1], y), Math.max(a[2], x), Math.max(a[3], y)]; }));
    return a;
  }

  // Bebouwd deel van het perceel: rasteren op ~20.000 punten
  function builtShare(parcel, buildings) {
    const [x0, y0, x1, y1] = bboxOf(parcel);
    const step = Math.max(0.25, Math.sqrt(((x1 - x0) * (y1 - y0)) / 20000));
    const bb = buildings.map((b) => ({ polys: b, box: bboxOf(b) }));
    let inP = 0, inB = 0;
    for (let x = x0 + step / 2; x < x1; x += step) {
      for (let y = y0 + step / 2; y < y1; y += step) {
        if (!inPolys(x, y, parcel)) continue;
        inP++;
        if (bb.some((b) => x >= b.box[0] && x <= b.box[2] && y >= b.box[1] && y <= b.box[3] && inPolys(x, y, b.polys))) inB++;
      }
    }
    return inP ? inB / inP : 0;
  }

  async function getJSON(url) {
    const r = await fetch(url, { headers: { Accept: 'application/geo+json, application/json' } });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return r.json();
  }

  // ------------------------------------------------------------------
  // Adres zoeken (autocomplete)
  // ------------------------------------------------------------------
  let items = [], active = -1, timer = null, lastQ = '';
  function openList(v) { list.hidden = !v; addr.setAttribute('aria-expanded', v); }
  function renderList(docs) {
    items = docs; list.innerHTML = ''; active = -1;
    if (!docs.length) { openList(false); return; }
    docs.forEach((d, i) => {
      const li = document.createElement('li');
      li.setAttribute('role', 'option'); li.id = 'ts-opt-' + i;
      li.textContent = d.weergavenaam;
      li.addEventListener('mousedown', (e) => { e.preventDefault(); pick(i); });
      list.append(li);
    });
    openList(true);
  }
  async function suggest(q) {
    lastQ = q;
    try {
      const u = LS + '/suggest?rows=7&fq=type:adres&lat=' + WAGENINGEN[0] + '&lon=' + WAGENINGEN[1] + '&q=' + encodeURIComponent(q);
      const j = await getJSON(u);
      if (q !== lastQ) return;
      renderList((j.response && j.response.docs) || []);
    } catch (e) {
      setStatus('Adressen zoeken lukt nu even niet. Vul je tuin hieronder zelf in m² in.', 'warn');
    }
  }
  addr.addEventListener('input', () => {
    clearTimeout(timer);
    const q = addr.value.trim();
    if (q.length < 3) { openList(false); return; }
    timer = setTimeout(() => suggest(q), 200);
  });
  addr.addEventListener('keydown', (e) => {
    if (list.hidden) return;
    if (e.key === 'ArrowDown') { e.preventDefault(); hl(Math.min(items.length - 1, active + 1)); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); hl(Math.max(0, active - 1)); }
    else if (e.key === 'Enter') { e.preventDefault(); pick(active >= 0 ? active : 0); }
    else if (e.key === 'Escape') openList(false);
  });
  addr.addEventListener('blur', () => setTimeout(() => openList(false), 150));
  function hl(i) {
    [...list.children].forEach((li, j) => li.classList.toggle('is-active', j === i));
    active = i;
    if (i >= 0) addr.setAttribute('aria-activedescendant', 'ts-opt-' + i);
  }

  async function pick(i) {
    const d = items[i]; if (!d) return;
    addr.value = d.weergavenaam; openList(false);
    setStatus('Kadastrale kaart erbij pakken…', 'busy');
    try {
      const j = await getJSON(LS + '/lookup?fl=id,weergavenaam,centroide_ll,gemeentenaam&id=' + encodeURIComponent(d.id));
      const doc = j.response.docs[0];
      const m = /POINT\(([-\d.]+) ([-\d.]+)\)/.exec(doc.centroide_ll);
      const lon = parseFloat(m[1]), lat = parseFloat(m[2]);
      state.address = doc.weergavenaam; state.gemeente = doc.gemeentenaam || '';
      await scan(lat, lon);
    } catch (e) {
      console.warn(e);
      setStatus('Het lukte niet om de kaart op te halen. Vul je tuin hieronder zelf in m² in, dat werkt ook.', 'warn');
    }
  }

  // ------------------------------------------------------------------
  // Perceel + gebouwen ophalen en tuin uitrekenen
  // ------------------------------------------------------------------
  async function scan(lat, lon) {
    initMap();
    let parcelF = null;
    for (const d of [0.0003, 0.0012]) {
      const bbox = [lon - d, lat - d * 0.62, lon + d, lat + d * 0.62].map((v) => v.toFixed(6)).join(',');
      const fc = await getJSON(KK + '?f=json&limit=100&bbox=' + bbox);
      const feats = fc.features || [];
      parcelF = feats.find((f) => inPolys(lon, lat, polysOf(f.geometry)));
      if (parcelF) break;
    }
    if (!parcelF) throw new Error('Geen perceel gevonden');

    const parcelLL = polysOf(parcelF.geometry);
    const box = bboxOf(parcelLL);
    const bagFc = await getJSON(BAG + '?f=json&limit=100&bbox=' + box.map((v) => v.toFixed(6)).join(','));
    const buildingsLL = (bagFc.features || [])
      .filter((f) => !f.properties || !/gesloopt|niet gerealiseerd|ingetrokken/i.test(f.properties.status || ''))
      .map((f) => polysOf(f.geometry));

    const parcelXY = project(parcelLL, lat, lon);
    const buildingsXY = buildingsLL.map((b) => project(b, lat, lon));
    const drawn = parcelXY.reduce((s, rings) => s + ringArea(rings[0]) - rings.slice(1).reduce((h, r) => h + ringArea(r), 0), 0);
    const official = Number(parcelF.properties && parcelF.properties.kadastrale_grootte_waarde) || 0;
    const parcelM2 = official > 0 ? official : drawn;
    const share = builtShare(parcelXY, buildingsXY);
    state.parcelM2 = parcelM2;
    state.buildingM2 = parcelM2 * share;
    const garden = Math.max(0, parcelM2 - state.buildingM2);

    // Tekenen
    layers.clearLayers();
    const toLL = (polys) => polys.map((rings) => rings.map((r) => r.map(([x, y]) => [y, x])));
    const parcelLayer = L.polygon(toLL(parcelLL), { color: '#E8B94A', weight: 3, fillColor: '#6FA13F', fillOpacity: 0.28 }).addTo(layers);
    buildingsLL.forEach((b) => L.polygon(toLL(b), { color: '#ffffff', weight: 1.5, dashArray: '4 3', fillColor: '#16241A', fillOpacity: 0.55, interactive: false }).addTo(layers));
    L.circleMarker([lat, lon], { radius: 5, color: '#fff', weight: 2, fillColor: '#E8B94A', fillOpacity: 1 }).addTo(layers);
    map.fitBounds(parcelLayer.getBounds(), { padding: [30, 30], maxZoom: 20 });

    $('tsParcel').textContent = m2(parcelM2);
    $('tsBuilt').textContent = m2(state.buildingM2);
    areaInput.value = Math.round(garden);
    root.classList.add('has-result');

    let msg = 'Gevonden! Perceel ' + (parcelF.properties.kadastrale_gemeente_waarde || '') + ' ' + (parcelF.properties.sectie || '') + ' ' + (parcelF.properties.perceelnummer || '') + '.';
    if (state.gemeente && !/wageningen/i.test(state.gemeente)) msg += ' Dit adres ligt buiten Wageningen, maar vraag het gerust: misschien komen we toch.';
    if (parcelM2 > 1500) msg += ' Groot perceel: daar hoort soms ook grond bij die geen tuin is. Pas de m² gerust aan.';
    setStatus(msg.replace(/\s+/g, ' ').trim(), 'ok');
    update();
  }

  // ------------------------------------------------------------------
  // Klussen en prijs
  // ------------------------------------------------------------------
  const boxes = [...root.querySelectorAll('.ts-tasks input[type="checkbox"]')];
  function syncExtras() {
    boxes.forEach((b) => {
      b.closest('.calc-check').classList.toggle('is-checked', b.checked);
      const t = EXTRA_TASKS[b.value];
      if (t && t.input) $(t.input).closest('.ts-extra').hidden = !b.checked;
    });
  }

  function update() {
    syncExtras();
    const a = Math.max(0, Number(areaInput.value) || 0);
    const chosen = boxes.filter((b) => b.checked).map((b) => b.value);
    const lines = [];
    chosen.forEach((v) => {
      if (SIZE_TASKS[v]) {
        if (!a) return;
        lines.push([SIZE_TASKS[v].label + ' · ' + m2(a), round5(sizePrice(SIZE_TASKS[v], a)), false]);
      } else if (EXTRA_TASKS[v]) {
        const t = EXTRA_TASKS[v];
        if (t.fixed) { lines.push([t.label, t.fixed, false]); return; }
        const n = Math.max(1, Math.round(Number($(t.input).value) || 0));
        lines.push([t.label + ' · ' + n + ' ' + (n === 1 ? t.unit : (t.units || t.unit)), n * t.per, !!t.noMin]);
      }
    });

    const out = $('tsLines'); out.innerHTML = '';
    lines.forEach(([label, amount]) => {
      const row = document.createElement('div'); row.className = 'calc-row';
      const l = document.createElement('span'); l.textContent = label;
      const r = document.createElement('span'); r.className = 'mono'; r.textContent = eur(amount);
      row.append(l, r); out.append(row);
    });

    const priceEl = $('tsPrice'), note = $('tsNote'), btn = $('tsBtn');
    if (!lines.length) {
      priceEl.textContent = '—';
      note.textContent = !a && chosen.some((v) => SIZE_TASKS[v])
        ? 'Zoek eerst je adres, of vul hierboven zelf je tuin in m² in.'
        : 'Kies wat er moet gebeuren.';
      btn.href = WA;
      return;
    }
    const base = lines.filter((l) => !l[2]).reduce((s, l) => s + l[1], 0);
    const extra = lines.filter((l) => l[2]).reduce((s, l) => s + l[1], 0);
    const raised = base > 0 && base < MIN_PRICE;
    const total = (base > 0 ? Math.max(MIN_PRICE, base) : 0) + extra;
    priceEl.textContent = eur(total);

    const hours = total / (2 * UURTARIEF);
    let n = 'Ongeveer ' + (Math.round(hours * 2) / 2).toLocaleString('nl-NL') + ' uur werk met z\'n tweeën. ';
    if (raised) n += 'Minimumprijs per bezoek is ' + eur(MIN_PRICE) + '. ';
    n += 'Dit is een inschatting: we komen gratis kijken en daarna is alles in overleg, ook per uur (' + eur(UURTARIEF) + ' p.p.).';
    note.textContent = n;

    const msg = 'Hoi Robin en Stian! ' + (state.address ? 'Adres: ' + state.address + '. ' : '') +
      (a ? 'Tuin ± ' + Math.round(a) + ' m². ' : '') +
      'Ik wil graag: ' + lines.map((l) => l[0].replace(' · ' + m2(a), '') + ' (' + eur(l[1]) + ')').join(', ') +
      '. Inschatting totaal ' + eur(total) + '. Wanneer kunnen jullie komen kijken?';
    btn.href = WA + '?text=' + encodeURIComponent(msg);
  }

  boxes.forEach((b) => b.addEventListener('change', update));
  [areaInput, $('tsTerras'), $('tsHeg'), $('tsStruik'), $('tsAfvoer')].forEach((el) => el && el.addEventListener('input', update));

  // Kaart pas laden als de sectie in beeld komt
  if ('IntersectionObserver' in window) {
    const io = new IntersectionObserver((es) => { if (es.some((e) => e.isIntersecting)) { initMap(); io.disconnect(); } }, { rootMargin: '200px' });
    io.observe(root);
  } else initMap();

  update();
})();
